import FileUtils
import datetime


def consolidateData(cities, startDate, endDate, outputFileName):
    pass
